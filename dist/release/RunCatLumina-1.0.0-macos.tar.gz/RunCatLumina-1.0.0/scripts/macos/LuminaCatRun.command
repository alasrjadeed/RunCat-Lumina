#!/usr/bin/env bash
exec "$(cd "$(dirname "$0")" && pwd)/start.sh"
